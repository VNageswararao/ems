<?php 
$path=base_url('template1/modern-admin/');
?>   
<script type="text/javascript">
    var doc_examination_id=<?php echo $doc_examination_id; ?>;
    var actionflag=<?php echo $actionflag; ?>;
row_numm=1;
</script>
<style type="text/css">
  table th 
  {
    background: #add8f4;
  }
  .table-bordered th, .table-bordered td {
    border: 1px solid #add8f4;
}
<?php if($doc_examination_id>0){ ?>

    <?php } else { ?>
     .pricss
    {
        display: none;
    }   
    <?php } ?>

 <?php if($actionflag==1 || $actionflag==0){  ?>
     .actionflagcls_foropth
    {
        display: block;
    }   
   
  <?php }else{  ?>
     .actionflagcls_foropth
    {
        display: none;
    }   
   <?php } ?>

   <?php if($actionflag==2){  ?>
     .actionflagcls_fordoc
    {
        display: block;
    }   
   
  <?php }else{  ?>
     .actionflagcls_fordoc
    {
        display: none;
    }   
   <?php } ?>

</style>   
 <div class="content-body">
             <!-- Justified With Top Border start -->
                 <section id="basic-tabs-components">
                    <div class="row match-height">
                        <div class="col-xl-12 col-lg-12">
                              <div class="card">
                                <div class="card-body">
                                 
                                  <ul class="nav nav-pills nav-pill-toolbar nav-justified">
                                    <li class="nav-item">
                                      <a class="nav-link active" id="active2-pill1" data-toggle="pill" href="#active21"
                                        aria-expanded="true"><l id="tab_tit">Examination<l></a>
                                    </li>
                                    <li class="nav-item" >
                                      <a class="nav-link" id="link2-pill1" data-toggle="pill" href="#link21" aria-expanded="false">Case History</a>
                                    </li>
                                 
                                    
                                  </ul>
                                  <div class="tab-content px-1 pt-1">
                                    <div role="tabpanel" class="tab-pane active" id="active21" aria-labelledby="active2-pill1"
                                      aria-expanded="true">
                                        <form id="examination_addmedhistorysaveform" action="#" method="post"> 
                                          <input type="hidden" name="csrf_test_name"  value="<?php echo $this->security->get_csrf_hash(); ?>">
                                         <div id="addmed_modal_view" style="display:none;">
                                                <div class="row">
                                                                <div class="col-md-6">
                                                                    <label>Select Medicine<span class="text-danger">*</span></label>
                                                                    <select class="form-control select2" name="medicine_id" id="medicine_id" onchange="getallmedicine(this.value)">
                                                                        <option value="">Select Medicine</option>
                                                                        <?php if($getallmedicine) foreach($getallmedicine as $data) { ?>
                                                                            <option value="<?php echo $data['medicine_id']; ?>"><?php echo $data['name']; ?></option>
                                                                      <?php } ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <br/>
                                                             <div class="row">
                                                                <div class="col-md-12">
                                                                 <div class="table-responsive">
                                                                     <table class="table table-hover" id="productdetails">
                                                                         <thead>
                                                                             <tr>
                                                                                 <th>Drug Name</th>
                                                                                 <th>Instruction</th>
                                                                                 <th>No.days</th>
                                                                                 <th>Qty</th>
                                                                                 <th style="display:none;">Start Date</th>
                                                                                 <th style="display:none;">End Date</th>
                                                                                 <th>Eye</th>
                                                                                 <th>Delete</th>
                                                                             </tr>
                                                                         </thead>
                                                                         <tbody>
                                                                             
                                                                         </tbody>
                                                                     </table>
                                                                 </div>
                                                             </div>
                                                             <br/>
                                                              <div class="col-md-6">
                                                                <label>Remarks</label>
                                                                <textarea class="form-control" name="medicine_doc_remarks" id="medicine_doc_remarks"></textarea>
                                                              </div>
                                                             </div>

                                <div class="card-footer ml-auto" id="m_btn_addmedhis">
                                    <button  class="btn btn-primary btn-sm" type="button" onclick="addmedhistorydetails();"><i class="fas fa-plus-square"></i>Submit</button>
                                    <button type="button"  class="btn btn-danger btn-sm"  onclick="backmedscreen()">Back</button>
                                </div>

                                         </div>
                                     </form>
                                         <form id="examination_addhistorysaveform" action="#" method="post"> 
                                  <input type="hidden" name="csrf_test_name"  value="<?php echo $this->security->get_csrf_hash(); ?>">
                                         <div id="add_modal_view" style="display:none;">
                                       
                                                           <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="table-responsive">
                                                                        <style type="text/css">
                                    

table.scroll tbody,
table.scroll thead { display: block; }



table.scroll tbody {
    height: 220px;
    overflow-y: auto;
    overflow-x: hidden;
}



.scroll tbody td, thead th {
    width: 10%; /* Optional */
  
}


                                                                        </style>
                                                        <table class="table table-bordered table-hover scroll" id="complaintidd" style="width:100%;">
                                  <thead>
                                     <tr><th colspan="4" style="text-align:center;">Complaints</th></tr>
                                      <tr style="position: relative;">
                                          <th>Sl No</th>
                                          <th>Complaints</th>
                                          <th>EYE</th>
                                          <th>Remarks</th>
                                      </tr>
                                  </thead>
                                  <tbody id="complaintid">
                                                                        </tbody>
                                                                    </table>
                                                                    <br/>
                                                                   
                                                                </div>
                                                                 <div id="comp_remm"></div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                     <div  id="opthol">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <hr/>

                                                             <div class="row">
                                                                <div class="col-md-6">
                                                                    <div  id="medicalhis">
                                                                    
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                      <div class="col-md-12">
                                                                         <label>Family History</label>
                                                                         <input type="text" name="family_history" id="family_history" class="form-control">
                                                                      </div>
                                                                       <div class="col-md-12">
                                                                         <label>Drug Allergy</label>
                                                                         <input type="text" name="drug_history" id="drug_history" class="form-control">
                                                                      </div>
                                                                       <div class="col-md-12">
                                                                         <label>Current Meditation</label>
                                                                         <input type="text" name="current_meditation" id="current_meditation" class="form-control">
                                                                      </div>
                                                                    
                                                                </div>
                                                            </div>
                                                            <hr/>

                                                         

                                <div class="card-footer ml-auto" id="m_btn_addhis">
                                    <button  class="btn btn-primary btn-sm" type="button" onclick="addhistorydetails();"><i class="fas fa-plus-square"></i>Submit</button>
                                    <button type="button"  class="btn btn-danger btn-sm"  onclick="backscreen()">Back</button>
                                </div>
                                        
                                       </div>
                                     </form>
                                     <div id="add_modal_view_screen">
                                      <form id="examination_saveform" action="#" method="post"> 
                                            <input type="hidden" name="doc_examination_id"  value="<?php echo $doc_examination_id; ?>">
                                             <input type="hidden" name="actionflagg"  value="<?php echo $actionflag; ?>">
                                        <input type="hidden" name="patient_registration_id" id="patient_registration_id" value="<?php echo $patient_registration_id; ?>">
                                         <input type="hidden" name="patient_appointment_id" id="patient_appointment_id" value="<?php echo $patient_appointment_id; ?>">
                                         <input type="hidden" name="history_id" id="history_id">
                                          <input type="hidden" name="addmedhistory_id" id="addmedhistory_id">
                                           <input type="hidden" name="csrf_test_name" id="csrf_test_name" value="<?php echo $this->security->get_csrf_hash(); ?>"> 
                                    <input type="hidden" id="hidgen_comp_remarks" name="hidgen_comp_remarks">
                                    <input type="hidden" id="hidgen_opth_remarks" name="hidgen_opth_remarks">
                                    <input type="hidden" id="hidgen_medi_remarks" name="hidgen_medi_remarks">
                                     <input type="hidden" id="examination_id" name="examination_id">
                                     <input type="hidden" id="examination_datee" name="examination_datee" value="<?php echo date('Y-m-d'); ?>">
                                      <div class="row alert bg-primary alert-dismissible mb-2">
                                          <div class="col-md-10">
                                                    <h5 style="color:#fff;"> Patient Name: <?=$pname?> MRD NO:<?=$mrdno?> Age-<?=$ageyy?> <?=$agemm?>/<?=$gender?>  <?=$address?> </h5>
                                          </div>
                                          <div class="col-md-2">
                                                
                                                <select class="form-control select2" name="doctor_id" id="doctor_id">
                                                    <option value="">Select Doctor</option>
                                                     <?php if($doctors){foreach($doctors as $data){
                                                        $sel='';
                                                        if($doc_examination_id)
                                                        {

                                                        }
                                                        else
                                                        {
                                                            if($docc_id==$data['doctors_registration_id'])
                                                            {
                                                                $sel='selected';
                                                            }
                                                        }
                                                      ?>
                                                        <option value="<?php echo $data['doctors_registration_id']; ?>"  <?php echo $sel; ?>><?php echo $data['name']; ?></option>
                                                        <?php } } ?>
                                                </select>
                                          </div>
                                        </div>
                                     
                                      <div class="row">
                                            <div class="col-md-6">
                                              
                                                <span class="btn btn-outline-danger btn-min-width btn-glow mr-1 mb-1" style="cursor: pointer;float:right;" onclick="addhistory()">Add History</span>
                                            </div>
                                      </div>
                             
                                      <div class="row" >
                                          <div class="col-md-6">
                                              <div class="table-responsive">
                                                  <table class="table table-bordered table-hover">
                                                      <thead>
                                                          <tr>
                                                              <th>Complaints</th>
                                                              <th>Current Medication</th>
                                                          </tr>
                                                      </thead>
                                                      <tbody id="comp_medicine">
                                                          
                                                      </tbody>
                                                  </table>
                                              </div>

                                              <div class="table-responsive">
                                                   <table class="table table-bordered table-hover">
                                                      <thead>
                                                          <tr>
                                                              <th>Opthalmic History</th>
                                                              <th>Medical History</th>
                                                              <th>Family History</th>
                                                              <th>Drug Allergy</th>
                                                          </tr>
                                                      </thead>
                                                      <tbody id="other_history">
                                                        
                                                      </tbody>
                                                  </table>
                                              </div>
                                              <div class="row">
                                                  <div class="col-md-12">
                                                      <input type="radio"  name="preliminary" checked>Preliminary Examination
                                                     
                                                  </div>
                                              </div>
                                              <div class="table-responsive">
                                <table class="table table-bordered">
                                    <tr>
                                        <td style="padding: 0px;">
                                            <table class="">
                                                <tr style="background: #75e7be !important;">
                                                    <th>Date</th>
                                                    <th class="tab_tit">NCT</th>
                                                    <th class="tab_tit">GAT</th>
                                                    <th class="tab_tit">CCT</th>
                                                    <th class="tab_tit">Angle</th>
                                                    <th class="tab_tit">Color Vision</th>
                                                    <th class="tab_tit">Pupil</th>
                                                </tr>
                                                 <tr >
                                                    <td class="tab_tit" style="background: #e0e0e057;">Right Eye</td>
                                                    <td style="padding:5px;"><input type="text" name="pre1" id="pre1" class="form-control"></td>
                                                    <td style="padding:5px;"><input type="text" name="pre2" id="pre2" class="form-control"></td>
                                                    <td style="padding:5px;"><input type="text" name="pre3" id="pre3" class="form-control"></td>
                                                    <td style="padding:5px;"><input type="text" name="pre4" id="pre4" class="form-control"></td>
                                                    <td style="padding:5px;"><input type="text" name="pre5" id="pre5" class="form-control"></td>
                                                    <td style="padding:5px;"><input type="text" name="pre6" id="pre6" class="form-control"></td>
                                                </tr>
                                                 <tr>
                                                    <td style="background: #e0e0e057;" class="tab_tit">Left Eye</td>
                                                    <td style="padding:5px;"><input type="text" name="pre7" id="pre7" class="form-control"></td>
                                                    <td style="padding:5px;"><input type="text" name="pre8" id="pre8" class="form-control"></td>
                                                    <td style="padding:5px;"><input type="text" name="pre9" id="pre9" class="form-control"></td>
                                                    <td style="padding:5px;"><input type="text" name="pre10" id="pre10" class="form-control"></td>
                                                    <td style="padding:5px;"><input type="text" name="pre11" id="pre11" class="form-control"></td>
                                                    <td style="padding:5px;"><input type="text" name="pre12" id="pre12" class="form-control"></td>
                                                </tr>
                                                <tr>
                                                    <td style="background: #e0e0e057;" class="tab_tit">Remarks</td>
                                                    <td style="padding:5px;" colspan="7"><input type="text" name="pre_remarks" id="pre_remarks" class="form-control"></td>
                                                    
                                                </tr>
                                            </table>
                                        </td>
                                      
                                    </tr>
                                </table>
                            </div> 
                            <br/>
                                                  <div class="row">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-hover">
                                                          <thead>
                                                             <tr>
                                                               <th>Right Eye</th>
                                                               <th style="background: #e0e0e057 !important;">Particulars</th>
                                                               <th>Left Eye</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody id="showdataeyecomp">
                                                            <?php foreach ($geteyecomp as $data) { ?>
                                                                 <tr>
                                                                    <td><input type="hidden" name="eye_complaints_id[]" value="<?php echo $data['eye_complaints_id']; ?>" class="form-control"><input type="text" name="righteye[]" class="form-control"></td>
                                                                    <td style="background: #e0e0e057;"><?php echo $data['name']; ?></td>
                                                                    <td><input type="text" name="lefteye[]" class="form-control"></td>
                                                                </tr>
                                                           <?php  }  ?>
                                                           </tbody>
                                                        </table>
                                                    </div>
                                                   

                                                  </div>
                                                   <br/>
                                                   <div class="row form-group">
                                                       <div class="col-md-4">
                                                            <label>Dilation</label>
                                                        <select class="form-control" name="dialysiscon" id="dialysiscon" onchange="checkdia(this.value);">
                                                                <option value="1">No</option>
                                                                <option value="2">Yes</option>
                                                        </select>
                                                       </div>
                                                       <div class="col-md-8" style="display:none;" id="drops">
                                                        <label>Dilation Drops</label>
                                                        <select class="form-control select2" name="dialysis_drops" id="dialysis_drops">
                                                             <option value="">Select Dilation Drops</option>
                                                <?php if($getalldialysis){ foreach($getalldialysis as $data){ ?>  
                                                     <option value="<?php echo $data['dialysis_id']; ?>"><?php echo $data['name']; ?></option>
                                                <?php } } ?>
                                                        </select>
                                                       </div>
                                                   </div>
                                                     <?php if($doc_examination_id>0 && $actionflag==2){  ?>
                                                   <div class="row form-group">
                                                    <div class="col-md-12">
                                                      
                                                 <span  class="badge badge-danger" style="cursor: pointer;float:right;" onclick="addmedhistory()">Add Medicine</span>
                                          
                                             <br/>
                                             </div>
                                                   </div>
                                                      <?php } ?>
                                                     
                                                     <div class="row form-group">
                                                         
                                                        <div class="col-md-12" id="doctor_medicine"></div>
                                                     </div>
                              
                                          </div>


                                           <div class="col-md-6">
                                                <div class="row">
                                                  <div class="col-md-12">
                                                      <input type="radio" name="lenstype" value="1" checked> Vision Readings
                                                      <input type="radio" name="lenstype" value="2"> Current Spectacle Prescription
                                                  </div>
                                              </div>

                                              <div class="row">
                                                  <div class="table-responsive" style="padding: 15px;margin-top: -18px;">
                                                      <table class="table table-bordered" id="Vision" >
                                                          <tr>
                                                            <th></th>
                                                            <th colspan="2" align="center">UCVA</th>
                                                            <th>PH</th>
                                                            <th colspan="2" align="center">BCVA</th>
                                                          </tr>
                                                          <tr style="background: #faebd747;">
                                                            <td></td>
                                                            <td>UCDVA</td>
                                                            <td>UCNVA</td>
                                                            <td>PH</td>
                                                            <td>UCDVA</td>
                                                            <td>UCNVA</td>
                                                          </tr>
                                                           <tr>
                                                              <td style="background: #faebd747;">Right Eye</td>
                                                              <td style="background: #e0e0e057;"><input type="text" name="vis1" id="vis1" class="form-control"></td>
                                                              <td style="background: #e0e0e057;"><input type="text" name="vis2" id="vis2" class="form-control"></td>
                                                              <td style="background: whitesmoke;"><input type="text" name="vis3" id="vis3" class="form-control"></td>
                                                              <td style="background: #ddd;"><input type="text" name="vis4" id="vis4" class="form-control"></td>
                                                              <td style="background: #ddd;"><input type="text" name="vis5" id="vis5" class="form-control"></td>
                                                          </tr>
                                                          <tr>
                                                              <td style="background: #faebd747;">Left Eye</td>
                                                              <td style="background: #e0e0e057;"><input type="text" name="vis6" id="vis6" class="form-control"></td>
                                                              <td style="background: #e0e0e057;"><input type="text" name="vis7" id="vis7" class="form-control"></td>
                                                              <td style="background: whitesmoke;"><input type="text" name="vis8" id="vis8" class="form-control"></td>
                                                              <td style="background: #ddd;"><input type="text" name="vis9" id="vis9" class="form-control"></td>
                                                              <td style="background: #ddd;"><input type="text" name="vis10" id="vis10" class="form-control"></td>
                                                          </tr>
                                                      </table>

                                     <table class="table table-bordered" id="spectacle" style="display: none;">
                                        <tr style="background: #1e9ff24f">
                                            <th align="center" class="tab_tit">RE</th>
                                            <th align="center" class="tab_tit">LE</th>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0px;">
                                                <table class="">
                                                    <tr style="background: #e0e0e057;">
                                                        <td style="background: #e0e0e057;"></th>
                                                        <td class="tab_tit">SPH</td>
                                                        <td class="tab_tit">CYL</td>
                                                        <td class="tab_tit">AXIS</td>
                                                        <td class="tab_tit">V/A</td>
                                                    </tr>
                                                     <tr>
                                                        <td class="tab_tit" style="background: #e0e0e057;">D.V</td>
                                                        <td style="padding:5px;"><input type="text" name="cur1" id="cur1" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="cur2" id="cur2" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="cur3" id="cur3" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="cur4" id="cur4" class="form-control"></td>
                                                    </tr>
                                                     <tr>
                                                        <td style="background: #e0e0e057;" class="tab_tit">N.V</td>
                                                        <td style="padding:5px;"><input type="text" name="cur5" id="cur5" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="cur6" id="cur6" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="cur7" id="cur7" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="cur8" id="cur8" class="form-control"></td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td style="padding: 0px;">
                                                <table class="">
                                                    <tr style="background: #e0e0e057;">
                                                        <td class="tab_tit">SPH</td>
                                                        <td class="tab_tit">CYL</td>
                                                        <td class="tab_tit">AXIS</td>
                                                        <td class="tab_tit">V/A</td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:5px;"><input type="text" name="cur9" id="cur9" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="cur10" id="cur10" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="cur11" id="cur11" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="cur12" id="cur12" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:5px;"><input type="text" name="cur13" id="cur13" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="cur14" id="cur14" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="cur15" id="cur15" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="cur16" id="cur16" class="form-control"></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                                  </div>
                                              </div>

                                              <div class="row">
                                                  <div class="col-md-12">
                                                      <input type="radio" name="refraction" value="1" checked> Objective Refraction
                                                      <input type="radio" name="refraction" value="2"> AR Kerotometry
                                                      <input type="radio" name="refraction" value="3"> Manual Kerotometry
                                                  </div>
                                              </div>

                                                <div class="row">
                                                  <div class="table-responsive" style="padding: 15px;margin-top: -18px;">
                                                      <table class="table table-bordered" id="Objective1">
                                                          <tr>
                                                            <th>UD</th>
                                                            <th>SPH</th>
                                                            <th>CYL</th>
                                                            <th>AXIS</th>
                                                            <th>CP</th>
                                                            <th>SPH</th>
                                                            <th>CYL</th>
                                                            <th>AXIS</th>
                                                          </tr>
                                                          <tr>
                                                             <td style="background: #faebd747;">RE</td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="obj1" id="obj1" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="obj2" id="obj2" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="obj3" id="obj3" class="form-control grid_table"></td>
                                                             <td style="background: #faebd747;">RE</td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="obj4" id="obj4" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="obj5" id="obj5" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="obj6" id="obj6" class="form-control grid_table"></td>
                                                          </tr>
                                                           <tr>
                                                             <td style="background: #faebd747;">LE</td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="obj7" id="obj7" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="obj8" id="obj8" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="obj9" id="obj9" class="form-control grid_table"></td>
                                                             <td style="background: #faebd747;">LE</td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="obj10" id="obj10" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="obj11" id="obj11" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="obj12" id="obj12" class="form-control grid_table"></td>
                                                          </tr>
                                                          <tr>
                                                            <td>IPD</td>
                                                            <td><input type="text" name="obj13" id="obj13" class="form-control grid_table"></td>
                                                            <td>PD RE</td>
                                                            <td><input type="text" name="obj14" id="obj14" class="form-control grid_table"></td>
                                                            <td>PD LE</td>
                                                            <td colspan="3"><input type="text" name="obj15" id="obj15" class="form-control grid_table"></td>
                                                          </tr>
                                                         
                                                      </table>
                                                        <table class="table table-bordered" id="Objective2" style="display:none">
                                                          <tr>
                                                            <th>ARK</th>
                                                            <th>K1</th>
                                                            <th>AXIS</th>
                                                            <th>K2</th>
                                                            <th>AXIS</th>
                                                            <th>CYL</th>
                                                            <th>AXIS</th>
                                                          </tr>
                                                          <tr>
                                                             <td style="background: #faebd747;">RE</td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="ar1" id="ar1" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="ar2" id="ar2" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="ar3" id="ar3" class="form-control grid_table"></td>
                                                             <td style="background: #faebd747;">RE</td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="ar4" id="ar4" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="ar5" id="ar5" class="form-control grid_table"></td>
                                                            
                                                          </tr>
                                                           <tr>
                                                             <td style="background: #faebd747;">LE</td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="ar6" id="ar6" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="ar7" id="ar7" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="ar8" id="ar8" class="form-control grid_table"></td>
                                                             <td style="background: #faebd747;">LE</td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="ar9" id="ar9" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="ar10" id="ar10" class="form-control grid_table"></td>
                                                             
                                                          </tr>
                                                      </table>
                                                      <table class="table table-bordered" id="Objective3" style="display:none">
                                                          <tr>
                                                            <th>MK</th>
                                                            <th>K1</th>
                                                            <th>AXIS</th>
                                                            <th>K2</th>
                                                            <th>AXIS</th>
                                                            <th>CYL</th>
                                                            <th>AXIS</th>
                                                          </tr>
                                                          <tr>
                                                             <td style="background: #faebd747;">RE</td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="man1" id="man1" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="man2" id="man2" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="man3" id="man3" class="form-control grid_table"></td>
                                                             <td style="background: #faebd747;">RE</td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="man4" id="man4" class="form-control grid_table"></td>
                                                              <td style="background: #e0e0e057;"><input type="text" name="man5" id="man5" class="form-control grid_table"></td>
                                                             
                                                          </tr>
                                                           <tr>
                                                             <td style="background: #faebd747;">LE</td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="man6" id="man6" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="man7" id="man7" class="form-control grid_table"></td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="man8" id="man8" class="form-control grid_table"></td>
                                                             <td style="background: #faebd747;">LE</td>
                                                             <td style="background: #e0e0e057;"><input type="text" name="man9" id="man9" class="form-control grid_table"></td>
                                                              <td style="background: #e0e0e057;"><input type="text" name="man10" id="man10" class="form-control grid_table"></td>
                                                            
                                                          </tr>
                                                       
                                                         
                                                      </table>
                                                  </div>
                                              </div>

                                               <div class="row">
                                                  <div class="col-md-12">
                                                      <input type="radio" name="spectacle" value="1" checked> Spectacle Correction
                                                      <input type="radio" name="spectacle" value="2"> Contact Lens Correction
                                                      <input type="radio" name="spectacle" value="3"> PMT Correction
                                                  </div>
                                              </div>

                                              <div class="row">
                                                 <div class="table-responsive" style="padding: 15px;margin-top: -18px;">
                                    <table class="table table-bordered" id="spectacle1">
                                        <tr style="background: #1e9ff24f">
                                            <th align="center" class="tab_tit">RE</th>
                                            <th align="center" class="tab_tit">LE</th>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0px;">
                                                <table class="">
                                                    <tr style="background: #e0e0e057;">
                                                        <td style="background: #e0e0e057;"></th>
                                                        <td class="tab_tit">SPH</td>
                                                        <td class="tab_tit">CYL</td>
                                                        <td class="tab_tit">AXIS</td>
                                                        <td class="tab_tit">V/A</td>
                                                    </tr>
                                                     <tr>
                                                        <td class="tab_tit" style="background: #e0e0e057;">D.V</td>
                                                        <td style="padding:5px;"><input type="text" name="spe1" id="spe1" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="spe2" id="spe2" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="spe3" id="spe3" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="spe4" id="spe4" class="form-control"></td>
                                                    </tr>
                                                     <tr>
                                                        <td style="background: #e0e0e057;" class="tab_tit">N.V</td>
                                                        <td style="padding:5px;"><input type="text" name="spe5" id="spe5" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="spe6" id="spe6" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="spe7" id="spe7" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="spe8" id="spe8" class="form-control"></td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td style="padding: 0px;">
                                                <table class="">
                                                    <tr style="background: #e0e0e057;">
                                                        <td class="tab_tit">SPH</td>
                                                        <td class="tab_tit">CYL</td>
                                                        <td class="tab_tit">AXIS</td>
                                                        <td class="tab_tit">V/A</td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:5px;"><input type="text" name="spe9" id="spe9" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="spe10" id="spe10" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="spe11" id="spe11" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="spe12" id="spe12" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:5px;"><input type="text" name="spe13" id="spe13" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="spe14" id="spe14" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="spe15" id="spe15" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="spe16" id="spe16" class="form-control"></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>

                                     <table class="table table-bordered" id="spectacle2" style="display:none;">
                                        <tr style="background: #1e9ff24f">
                                            <th align="center" class="tab_tit">RE</th>
                                            <th align="center" class="tab_tit">LE</th>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0px;">
                                                <table class="">
                                                    <tr style="background: #e0e0e057;">
                                                        <td style="background: #e0e0e057;"></th>
                                                        <td class="tab_tit">SPH</td>
                                                        <td class="tab_tit">CYL</td>
                                                        <td class="tab_tit">AXIS</td>
                                                        <td class="tab_tit">V/A</td>
                                                    </tr>
                                                     <tr>
                                                        <td class="tab_tit" style="background: #e0e0e057;">D.V</td>
                                                        <td style="padding:5px;"><input type="text" name="con1" id="con1" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="con2" id="con2" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="con3" id="con3" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="con4" id="con4" class="form-control"></td>
                                                    </tr>
                                                     <tr>
                                                        <td style="background: #e0e0e057;" class="tab_tit">N.V</td>
                                                        <td style="padding:5px;"><input type="text" name="con5" id="con5" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="con6" id="con6" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="con7" id="con7" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="con8" id="con8" class="form-control"></td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td style="padding: 0px;">
                                                <table class="">
                                                    <tr style="background: #e0e0e057;">
                                                        <td class="tab_tit">SPH</td>
                                                        <td class="tab_tit">CYL</td>
                                                        <td class="tab_tit">AXIS</td>
                                                        <td class="tab_tit">V/A</td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:5px;"><input type="text" name="con9" id="con9" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="con10" id="con10" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="con11" id="con11" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="con12" id="con12" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:5px;"><input type="text" name="con13" id="con13" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="con14" id="con14" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="con15" id="con15" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="con16" id="con16" class="form-control"></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>

                                     <table class="table table-bordered" id="spectacle3" style="display:none;">
                                        <tr style="background: #1e9ff24f">
                                            <th align="center" class="tab_tit">RE</th>
                                            <th align="center" class="tab_tit">LE</th>
                                        </tr>
                                        <tr>
                                            <td style="padding: 0px;">
                                                <table class="">
                                                    <tr style="background: #e0e0e057;">
                                                        <td style="background: #e0e0e057;"></th>
                                                        <td class="tab_tit">SPH</td>
                                                        <td class="tab_tit">CYL</td>
                                                        <td class="tab_tit">AXIS</td>
                                                        <td class="tab_tit">V/A</td>
                                                    </tr>
                                                     <tr>
                                                        <td class="tab_tit" style="background: #e0e0e057;">D.V</td>
                                                        <td style="padding:5px;"><input type="text" name="pmt1" id="pmt1" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="pmt2" id="pmt2" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="pmt3" id="pmt3" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="pmt4" id="pmt4" class="form-control"></td>
                                                    </tr>
                                                     <tr>
                                                        <td style="background: #e0e0e057;" class="tab_tit">N.V</td>
                                                        <td style="padding:5px;"><input type="text" name="pmt5" id="pmt5" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="pmt6" id="pmt6" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="pmt7" id="pmt7" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="pmt8" id="pmt8" class="form-control"></td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td style="padding: 0px;">
                                                <table class="">
                                                    <tr style="background: #e0e0e057;">
                                                        <td class="tab_tit">SPH</td>
                                                        <td class="tab_tit">CYL</td>
                                                        <td class="tab_tit">AXIS</td>
                                                        <td class="tab_tit">V/A</td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:5px;"><input type="text" name="pmt9" id="pmt9" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="pmt10" id="pmt10" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="pmt11" id="pmt11" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="pmt12" id="pmt12" class="form-control"></td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:5px;"><input type="text" name="pmt13" id="pmt13" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="pmt14" id="pmt14" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="pmt15" id="pmt15" class="form-control"></td>
                                                        <td style="padding:5px;"><input type="text" name="pmt16" id="pmt16" class="form-control"></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </div> 
                                              </div>

                                              <div class="row form-group" style="display:none;">
                                                <div class="col-md-3">
                                                    <label>Material</label>
                                                    <input type="text" name="material" id="material" class="form-control">
                                                </div>
                                                <div class="col-md-3">
                                                    <label>CR</label>
                                                    <input type="text" name="cr" id="cr" class="form-control">
                                                </div>
                                                <div class="col-md-3">
                                                    <label>Usage</label>
                                                    <input type="text" name="usage" id="usage" class="form-control">
                                                </div>
                                                <div class="col-md-3">
                                                    <label>Type</label>
                                                    <input type="text" name="typev" id="typev" class="form-control">
                                                </div>
                                              </div>

                                              <div class="row ">
                                                <div class="col-md-2">
                                                    <label>IPD</label>
                                                    <input type="text" name="ipd" id="ipd" class="form-control">
                                                </div>
                                                <div class="col-md-2">
                                                    <label>PD RE</label>
                                                    <input type="text" name="pdre" id="pdre" class="form-control">
                                                </div>
                                                <div class="col-md-2">
                                                    <label>LE</label>
                                                    <input type="text" name="le" id="le" class="form-control">
                                                </div>
                                                <div class="col-md-3">
                                                    <label>Segment RE</label>
                                                    <input type="text" name="segmentre" id="segmentre" class="form-control">
                                                </div>
                                                <div class="col-md-2">
                                                    <label>LE</label>
                                                    <input type="text" name="lle" id="lle" class="form-control">
                                                </div>
                                              </div>
                                              <hr/ style="background: black;">
                                              <div class="row">
                                                  <div class="col-md-12">
                                                      <input type="checkbox" name="followup" id="followup"> Follow Up
                                                      <input type="checkbox" name="workup" id="workup"> Work Up Plan
                                                  </div>
                                              </div>

                                              <div class="row ">
                                                <div class="col-md-2">
                                                    <label>MM</label>
                                                    <input type="text" name="mm" id="mm" class="form-control">
                                                </div>
                                                <div class="col-md-2">
                                                    <label>WWW</label>
                                                    <input type="text" name="www" id="www" class="form-control">
                                                </div>
                                                <div class="col-md-2">
                                                    <label>Days</label>
                                                    <input type="text" name="dayss" id="dayss" class="form-control">
                                                </div>
                                                <div class="col-md-4">
                                                    <label>Date</label>
                                                    <input type="date" name="d_date" id="d_date" class="form-control">
                                                </div>
                                                <div class="col-md-2">
                                                    <label>SOS</label>
                                                    <input type="text" name="sos" id="sos" class="form-control">
                                                </div>
                                              </div>
                                              <div class="row ">
                                                <div class="col-md-12">
                                                    <label>Plan Of Action</label>
                                                    <input type="text" name="plan_of_action" id="plan_of_action" class="form-control">
                                                </div>
                                               
                                              </div>
                                                  <div class="row form-group">
                                                <div class="col-md-12">
                                                    <label>Opthalmic User Comments</label>
                                                    <input type="text" name="opth_user_comments" id="opth_user_comments" class="form-control">
                                                </div>
                                               
                                              </div>
                                              <div class="row " >
                                                  <div class="col-sm-6 col-md-6 docscr" style="display:none;">
                                            <div class="form-group">
                                                <label for="lastname">Select Investigation Particulars: <span class="text-danger">*</span></label>
                                                    <select class="form-control select2" name="particular" id="particular" onchange="getparticularsdetails(this.value)">
                                                       
                                                    </select>
                                                        </div>
                                                     </div>
                                                        
                                                   
                                                       <div class="col-sm-6 col-md-6 actionflagcls_foropth">
                                                         <div class="form-group">
                                                            <label>Action</label>
                                                            <select class="form-control select2" name="optho_action" id="optho_action">
                                                                <option value="0">Inprogress</option>
                                                                <option value="1">Completed</option>
                                                            </select>
                                                        </div>
                                                           </div>
                                                     
                                                
                                                   
                                                       <div class="col-sm-6 col-md-6 actionflagcls_fordoc">
                                            <div class="form-group">
                                                <label for="lastname">Action: <span class="text-danger">*</span></label>
                                                         <select class="form-control select2" name="doc_action" id="doc_action">
                                                               <option value="0">Inprogress</option>
                                                               <option value="1">Completed</option>
                                                        </select>
                                                        </div>
                                                     </div>
                                               
                                              </div>
                                            <div class="row docscr" style="display:none;">
                                                 <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-hover" id="productdetailsinv" bquotation="0">
                                                    <thead style="background:#e0e0e0;">
                                                    <tr>
                                                        <th>Remove</th>
                                                        <th>Particulars</th>
                                                        <th>Rate</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                       
                                                    </tbody>
                                                </table>
                                                     </div>
                                             </div>
                                               </div>


                                           </div>

                                         

                                      </div>
                                <div class="card-footer ml-auto" id="m_btn_exm">
                                    <button id="save" type="button" class="btn btn-success btn-min-width btn-glow mr-1 mb-1" onclick="savedata();">Submit</button>
                                     <button style="display:none;" id="update" type="button" class="btn btn-warning btn-min-width btn-glow mr-1 mb-1" onclick="updatedataexamination();">
                                        <?php if($doc_examination_id>0 && $actionflag==2){ ?> Save <?php  }else { ?>Update <?php } ?> 
                                     </button>
                                     <button type="button" class="btn btn-info btn-min-width btn-glow mr-1 mb-1" onclick="this.form.reset();">Reset</button>
                                </div>
                                    </form>
                                  </div>
                                  
                                    </div>
                                    <div class="tab-pane" id="link21" role="tabpanel" aria-labelledby="link2-pill1" aria-expanded="false">
                                        <div class="row">
                                           <div class="col-md-6"></div>
                                         
                                           <div class="col-md-4">
                                                <button style="padding: 4px 9px;" onclick="getexaminationdata(doc_examination_id)" class="btn btn-icon btn-warning mr-1 mb-1" type="button">Show Records</button>
                                          </div>
                                           <div class="col-md-2" >
                                                <button style="padding: 4px 9px;float: right;"  class="btn btn-icon btn-info mr-1 mb-1" type="button"><i class="la la-cog" onclick="showmodal()"></i></button>
                                          </div>
                                        </div>

                                        <div id="modaldiv_modal" class="modal fade" role="dialog" aria-hidden="true" style="display: none;">
                                    <div class="modal-dialog modal-sm">
                                    <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Print Settings</h4>
                                                <button type="button" class="close" data-dismiss="modal">×</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="table-responsive">
                                                  <table class="table table-bordered table-hover">
                                                      <thead>
                                                          <tr>
                                                              <th>#</th>
                                                              <th>Names</th>
                                                          </tr>
                                                      </thead>
                                                      <tbody>
                                                          <tr>
                                                              <td><input type="checkbox" name="chkcomplaints" id="chkcomplaints" checked value="1"></td>
                                                              <td>Complaints</td>
                                                          </tr>
                                                           <tr>
                                                              <td><input type="checkbox" name="chkophthalmic " id="chkophthalmic" checked value="1"></td>
                                                              <td>Ophthalmic History</td>
                                                          </tr>
                                                          <tr>
                                                              <td><input type="checkbox" name="chkmedical" id="chkmedical" checked value="1"></td>
                                                              <td>Medical History</td>
                                                          </tr>
                                                          <tr>
                                                              <td><input type="checkbox" name="chkeyepart" id="chkeyepart" checked value="1"></td>
                                                              <td>EYE Particulars</td>
                                                          </tr>
                                                          <tr class="pricss">
                                                              <td><input type="checkbox" name="addmediciness" id="addmediciness" checked value="1"></td>
                                                              <td>Medicine</td>
                                                          </tr>
                                                           <tr class="pricss">
                                                              <td><input type="checkbox" name="investigationchk" id="investigationchk" checked value="1"></td>
                                                              <td>Investigation</td>
                                                          </tr>
                                                          <tr>
                                                              <td><input type="checkbox" name="preliminary_ex" id="preliminary_ex" checked value="1"></td>
                                                              <td>Preliminary Examination</td>
                                                          </tr>
                                                          <tr>
                                                              <td><input type="checkbox" name="vsisonreadings" id="vsisonreadings" checked value="1"></td>
                                                              <td>Vision Readings</td>
                                                          </tr>
                                                          <tr>
                                                              <td><input type="checkbox" name="curspec" id="curspec" checked value="1"></td>
                                                              <td>Current Spectacle Prescription</td>
                                                          </tr>
                                                          <tr>
                                                              <td><input type="checkbox" name="objectchk" id="objectchk" checked value="1"></td>
                                                              <td>Objective Refraction</td>
                                                          </tr>
                                                          <tr>
                                                              <td><input type="checkbox" name="arkkchk" id="arkkchk" checked value="1"></td>
                                                              <td> AR Kerotometry</td>
                                                          </tr>
                                                          <tr>
                                                              <td><input type="checkbox" name="manchk" id="manchk" checked value="1"></td>
                                                              <td>Manual Kerotometry</td>
                                                          </tr>
                                                           <tr>
                                                              <td><input type="checkbox" name="specchk" id="specchk" checked value="1"></td>
                                                              <td>Spectacle Correction</td>
                                                          </tr>
                                                          <tr>
                                                              <td><input type="checkbox" name="conlchk" id="conlchk" checked value="1"></td>
                                                              <td> Contact Lens Correction</td>
                                                          </tr>
                                                          <tr>
                                                              <td><input type="checkbox" name="pmtchk" id="pmtchk" checked value="1"></td>
                                                              <td>PMT Correction</td>
                                                          </tr>
                                                      </tbody>
                                                  </table>
                                                  </div>
                                                  </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
        <button id="save" class="btn btn-primary btn-sm" type="button" onclick="printsubmit();"><i class="fas fa-plus-square"></i>Submit</button>
            <button type="button" id="mclose" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                        <div class="row">
                                            <div class="col-md-12" id="examination_data"></div>
                                        </div>
                                    </div>
                                   
                                  </div>
                              </div>
                          </div>
                        </div>

                    </div>
                </section>
                <!-- Justified With Top Border end -->
            </div>



          <script type="text/javascript">
         function showmodal() {
              $('#modaldiv_modal').modal('show');
         }
         function printsubmit()
         {
            Swal.fire({title:"",text:"Saved data",type:"success",confirmButtonClass:"btn btn-success",buttonsStyling:!1});
            $('#mclose').click();
         }
             $("body").removeClass(" vertical-layout vertical-menu 2-columns fixed-navbar pace-done menu-expanded").addClass( "vertical-layout vertical-menu 2-columns fixed-navbar pace-done menu-collapsed" );
         
          </script>
       
<style type="text/css">
    .nav.nav-pills.nav-justified {
    width: 35%;
}
.table th, .table td {
    padding: 0.55rem 1.5rem;
}
.grid_table {
   
    width: 70px;
}
#complaintidd_paginate,#complaintidd_length ,#complaintidd_info,#opthold_paginate,#opthold_length ,#opthold_info,#medicalhist_paginate,#medicalhist_length ,#medicalhist_info
{
    display: none;medicalhist
}
</style>
<script type="text/javascript">
     row_num=1;
      cd = (new Date()).toISOString().split('T')[0];
      csrf='<?php echo $this->security->get_csrf_hash(); ?>';
    function getallmedicine(val)
    {
        if(val>0)
        {
            $("#overlay").fadeIn(300);
            $.ajax({
            type: "POST",
            url: 'getmedinedetails',
            dataType: "json",
            data: {medid:val,csrf_test_name:csrf},
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != '')
              {
                
                        $('#productdetails').children('tbody').append('<tr>\n\
                                       <td>'+data.getdata[0]['drugname']+'</td>\n\
                                       <td><input type="hidden" class="form-control" id="medicine_id_'+row_num+'" name="medicine_id[]" value="'+val+'"><input type="text" class="form-control" id="instruction_'+row_num+'" name="instruction[]" value="'+data.getdata[0]['instruction']+'"></td>\n\
                                       <td><input type="text" class="form-control" id="days_'+row_num+'" name="days[]" value="'+data.getdata[0]['days']+'"></td>\n\
                                        <td><input type="text" class="form-control" id="qty_'+row_num+'" name="qty[]" value="1"></td>\n\
                                        <td style="display:none;"><input type="date" class="form-control" id="sdate_'+row_num+'" name="sdate[]" value="'+cd+'"></td>\n\
                                         <td style="display:none;"><input type="date" class="form-control" id="tdate_'+row_num+'" name="tdate[]" value="'+cd+'"></td>\n\
                                          <td><select class="form-control" name="medeye[]" id="medeye_'+row_num+'"><option value="BE">BE</option><option value="LE">LE</option><option value="RE">RE</option><option value="N/A">N/A</option></select></td>\n\
                                           <td>\n\
                                            <a  onclick="$(this).parent().parent().remove();calcnet();" class="input_column">\n\
                                            <button class="btn btn-danger btnDelete btn-sm">\n\
                                               <i class="la la-trash"></i>\n\
                                            </button>\n\
                                            </a>\n\
                                       </td>\n\
                                         </tr>'); 
                         row_num++;

              } else if(data.error != '')
              {
                 $('#complaintid').html('No Data Found');
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) 
                {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },

            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }

        }); 
        }
    }
    function calcnet()
    {

    }
    function checkdia(val)
    {
       if(val==2)
       {
            $('#drops').show();
       }
       else
       {
            $('#drops').hide();
       }
    }

     
    
    $('#examination_date').val(cd);
     $('#d_date').val(cd);
 
   function getexaminationdata(sel=0)
   {
        $("#overlay").fadeIn(300);
        $('#examination_data').html('');
         $.ajax({
            type: "POST",
            url: 'getexaminationdata',
            dataType: "json",
            data: {doc_exam:sel,csrf_test_name:csrf,examination_date:$('#examination_date').val(),patient_registration_id:$('#patient_registration_id').val()},
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != '')
              {
                      $('#examination_data').html(data.dataexam);
                      $('#ex_datatable').DataTable({
                           dom: 'Bfrtip',
                           buttons: [
                            'pdfHtml5'
                          ],
                         
                           "lengthMenu": [[1000,10,25, 50, 100, 1000], [1000,10,25, 50, 100, 1000]]
                        });
              } else if(data.error != '')
              {
                 $('#complaintid').html('No Data Found');
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) 
                {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },
            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }

        });
   }

   $( document ).ready(function() {
      
     
        if(doc_examination_id>0)
        {
            editdata(doc_examination_id);
            getparticulars(5);
            if(actionflag!=1){
            $('.docscr').show();
            }
        }
        else
        {
             showhisdet();
        }

   }

   );
function getparticularsdetails(val)
{
    
    chargetype_id=5;
    if(val>0 && chargetype_id>0)
    {
         $("#overlay").fadeIn(300);
     $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>transaction/Billing/getparticularsdetails',
            dataType: "json",
            data: {chargetype_id:chargetype_id,getid: val,csrf_test_name:$('#csrf_test_name').val()},
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != ''){
                            
                            
                                id="investigation_id";
                 var html='<tr>\n\
                  <td>\n\
                        <a href="#" onclick="$(this).parent().parent().remove();" class="input_column">\n\
                        <button class="btn btn-danger btnDelete btn-sm">\n\
                           <i class="la la-trash"></i>\n\
                        </button>\n\
                        </a>\n\
                     </td><td>'+data.msg[0]['name']+'</td>\n\
                <td><input type="text" step="any" name="rate[]" id="rate_'+row_numm+'" class="form-control grid_table" value="'+data.msg[0]['amount']+'"     autocomplete="off"></td>\n\
                <td style="display:none;">row_numm\n\
                  <input type="hidden" id="calrow_id_'+row_numm+'" name="calrow_id[]" value="'+row_numm+'" >\n\
                  <input type="hidden" id="particularsid_'+row_numm+'" name="particularsid[]" value="'+data.msg[0][id]+'" >\n\
                   <input type="hidden" name="chargesid[]" id="chargesid_'+row_numm+'" class="form-control grid_table" value="'+chargetype_id+'" readonly="">\n\
                </td>\n\
                     </tr>';
                     row_numm++;
                    $('#productdetailsinv').children('tbody').append(html);
              } else if(data.error != ''){
                Swal.fire({title:"Warning!",text:""+data.error+"",type:"warning",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },
            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }
        });
    }
}

   function showhisdet()
   {
     $.fn.dataTable.ext.errMode = 'none';
      $.ajax({
            type: "POST",
            url: 'getcompalints',
            dataType: "json",
            data: {his_id:$('#history_id').val(),csrf_test_name:csrf},
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != '')
              {
                    
                     $('#complaintid').html(data.getdata);
                      $('#complaintidd').DataTable({
                           dom: 'Bfrtip',
                           buttons: [
                            'pdfHtml5'
                          ],
                          
                           "autoWidth": false,

                           "lengthMenu": [[1000,10,25, 50, 100, 1000], [1000,10,25, 50, 100, 1000]]
                        });
                      $('#comp_remm').html(data.comrem);

                      $('#opthol').html(data.optho);
                       $('#opthold').DataTable({
                           dom: 'Bfrtip',
                           buttons: [
                            'pdfHtml5'
                          ],
                           "lengthMenu": [[5,10,25, 50, 100, 1000], [5,10,25, 50, 100, 1000]]
                        });

                        $('#medicalhis').html(data.medi);
                       $('#medicalhist').DataTable({
                           dom: 'Bfrtip',
                           buttons: [
                            'pdfHtml5'
                          ],
                           "lengthMenu": [[5,10,25, 50, 100, 1000], [5,10,25, 50, 100, 1000]]
                        });

                        $('.dataTables_wrapper').css('width', '100%');


              } else if(data.error != '')
              {
                 $('#complaintid').html('No Data Found');
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) 
                {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },

            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }

        });

   }
function addmedhistory()
{
   $('.badge-success').hide(1000);
   $('#addmed_modal_view').show(1000);
   $('#add_modal_view_screen').hide(1000);
   $('#m_btn_exm').hide(1000); 
}
function backmedscreen()
{
   $('.badge-success').show(1000);
   $('#addmed_modal_view').hide(1000);
   $('#add_modal_view_screen').show(1000);
   $('#m_btn_exm').show(1000);
   window.scrollTo({top: 0, behavior: 'smooth'});
}

function addhistory()
{
   $('.badge-success').hide(1000);
   $('#add_modal_view').show(1000);
   $('#add_modal_view_screen').hide(1000);
   $('#m_btn_exm').hide(1000); 
}
function backscreen()
{
   $('.badge-success').show(1000);
   $('#add_modal_view').hide(1000);
   $('#add_modal_view_screen').show(1000);
   $('#m_btn_exm').show(1000);
   window.scrollTo({top: 0, behavior: 'smooth'});
}

function addhistorydetails()
{
        $("#overlay").fadeIn(300);
         $.ajax({
            type: "POST",
            url: 'addhistorysave',
            dataType: "json",
            data: $('#examination_addhistorysaveform').serialize(),
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != ''){
                 getaddhistorydata(data.key);
               Swal.fire({title:"",text:""+data.msg+"",type:"success",confirmButtonClass:"btn btn-success",buttonsStyling:!1});
               $('#history_id').val(data.key);
                $('#hidgen_comp_remarks').val($('#gen_comp_remarks').val());
                $('#hidgen_opth_remarks').val($('#gen_opth_remarks').val());
                $('#hidgen_medi_remarks').val($('#gen_medi_remarks').val());
               backscreen();

              
              } else if(data.error != ''){
               // Swal.fire({title:"Warning!",text:""+data.error+"",type:"warning",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },
            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }
        }); 

}
function addmedhistorydetails()
{
        $("#overlay").fadeIn(300);
         $.ajax({
            type: "POST",
            url: 'addmedhistorysave',
            dataType: "json",
            data: $('#examination_addmedhistorysaveform').serialize(),
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != ''){
                   getaddmedhistorydata(data.key);
                   Swal.fire({title:"",text:""+data.msg+"",type:"success",confirmButtonClass:"btn btn-success",buttonsStyling:!1});
                   $('#addmedhistory_id').val(data.key);
                   backmedscreen();
              } else if(data.error != ''){
               // Swal.fire({title:"Warning!",text:""+data.error+"",type:"warning",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },
            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }
        }); 

}

function editdata(key)
{
    if(doc_examination_id>0)
    {
        $('#case2nd').hide();
    }

        $("#overlay").fadeIn(300);
         $.ajax({
            type: "POST",
            url: 'geteditdata',
            dataType: "json",
            data: {getid:key,csrf_test_name:csrf},
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != ''){
                  $('#active2-pill1').click(); 
                  if(doc_examination_id==0){
                  $('#tab_tit').html('Edit Examination Entry');
                  }
                  $('#history_id').val(data.mastertable[0]['history_id']);
                  $('#examination_datee').val(data.mastertable[0]['examination_date']);
                  $('#examination_id').val(data.mastertable[0]['examination_id']);
                  $('#family_history').val(data.mastertable[0]['family_history']);
                  $('#drug_history').val(data.mastertable[0]['drug_history']);
                  $('#current_meditation').val(data.mastertable[0]['current_meditation']);
                  $("#doctor_id").val(data.mastertable[0]['doctor_id']).trigger("change");

                  $('#pre1').val(data.mastertable[0]['pre1']);
                  $('#pre2').val(data.mastertable[0]['pre2']);
                  $('#pre3').val(data.mastertable[0]['pre3']);
                  $('#pre4').val(data.mastertable[0]['pre4']);
                  $('#pre5').val(data.mastertable[0]['pre5']);
                  $('#pre6').val(data.mastertable[0]['pre6']);
                  $('#pre7').val(data.mastertable[0]['pre7']);
                  $('#pre8').val(data.mastertable[0]['pre8']);
                  $('#pre9').val(data.mastertable[0]['pre9']);
                  $('#pre10').val(data.mastertable[0]['pre10']);
                  $('#pre11').val(data.mastertable[0]['pre11']);
                  $('#pre12').val(data.mastertable[0]['pre12']);
                  $('#pre_remarks').val(data.mastertable[0]['pre_remarks']);

                  $('#vis1').val(data.mastertable[0]['vis1']);
                  $('#vis2').val(data.mastertable[0]['vis2']);
                  $('#vis3').val(data.mastertable[0]['vis3']);
                  $('#vis4').val(data.mastertable[0]['vis4']);
                  $('#vis5').val(data.mastertable[0]['vis5']);
                  $('#vis6').val(data.mastertable[0]['vis6']);
                  $('#vis7').val(data.mastertable[0]['vis7']);
                  $('#vis8').val(data.mastertable[0]['vis8']);
                  $('#vis9').val(data.mastertable[0]['vis9']);
                  $('#vis10').val(data.mastertable[0]['vis10']);

                  $('#cur1').val(data.mastertable[0]['cur1']);
                  $('#cur2').val(data.mastertable[0]['cur2']);
                  $('#cur3').val(data.mastertable[0]['cur3']);
                  $('#cur4').val(data.mastertable[0]['cur4']);
                  $('#cur5').val(data.mastertable[0]['cur5']);
                  $('#cur6').val(data.mastertable[0]['cur6']);
                  $('#cur7').val(data.mastertable[0]['cur7']);
                  $('#cur8').val(data.mastertable[0]['cur8']);
                  $('#cur9').val(data.mastertable[0]['cur9']);
                  $('#cur10').val(data.mastertable[0]['cur10']);
                  $('#cur11').val(data.mastertable[0]['cur11']);
                  $('#cur12').val(data.mastertable[0]['cur12']);
                  $('#cur13').val(data.mastertable[0]['cur13']);
                  $('#cur14').val(data.mastertable[0]['cur14']);
                  $('#cur15').val(data.mastertable[0]['cur15']);
                  $('#cur16').val(data.mastertable[0]['cur16']);

                  $('#obj1').val(data.mastertable[0]['obj1']);
                  $('#obj2').val(data.mastertable[0]['obj2']);
                  $('#obj3').val(data.mastertable[0]['obj3']);
                  $('#obj4').val(data.mastertable[0]['obj4']);
                  $('#obj5').val(data.mastertable[0]['obj5']);
                  $('#obj6').val(data.mastertable[0]['obj6']);
                  $('#obj7').val(data.mastertable[0]['obj7']);
                  $('#obj8').val(data.mastertable[0]['obj8']);
                  $('#obj9').val(data.mastertable[0]['obj9']);
                  $('#obj10').val(data.mastertable[0]['obj10']);
                  $('#obj11').val(data.mastertable[0]['obj11']);
                  $('#obj12').val(data.mastertable[0]['obj12']);
                  $('#obj13').val(data.mastertable[0]['obj13']);
                  $('#obj14').val(data.mastertable[0]['obj14']);
                  $('#obj15').val(data.mastertable[0]['obj15']);

                  $('#ar1').val(data.mastertable[0]['ar1']);
                  $('#ar2').val(data.mastertable[0]['ar2']);
                  $('#ar3').val(data.mastertable[0]['ar3']);
                  $('#ar4').val(data.mastertable[0]['ar4']);
                  $('#ar5').val(data.mastertable[0]['ar5']);
                  $('#ar6').val(data.mastertable[0]['ar6']);
                  $('#ar7').val(data.mastertable[0]['ar7']);
                  $('#ar8').val(data.mastertable[0]['ar8']);
                  $('#ar9').val(data.mastertable[0]['ar9']);
                  $('#ar10').val(data.mastertable[0]['ar10']);

                  $('#man1').val(data.mastertable[0]['man1']);
                  $('#man2').val(data.mastertable[0]['man2']);
                  $('#man3').val(data.mastertable[0]['man3']);
                  $('#man4').val(data.mastertable[0]['man4']);
                  $('#man5').val(data.mastertable[0]['man5']);
                  $('#man6').val(data.mastertable[0]['man6']);
                  $('#man7').val(data.mastertable[0]['man7']);
                  $('#man8').val(data.mastertable[0]['man8']);
                  $('#man9').val(data.mastertable[0]['man9']);
                  $('#man10').val(data.mastertable[0]['man10']);

                  $('#spe1').val(data.mastertable[0]['spe1']);
                  $('#spe2').val(data.mastertable[0]['spe2']);
                  $('#spe3').val(data.mastertable[0]['spe3']);
                  $('#spe4').val(data.mastertable[0]['spe4']);
                  $('#spe5').val(data.mastertable[0]['spe5']);
                  $('#spe6').val(data.mastertable[0]['spe6']);
                  $('#spe7').val(data.mastertable[0]['spe7']);
                  $('#spe8').val(data.mastertable[0]['spe8']);
                  $('#spe9').val(data.mastertable[0]['spe9']);
                  $('#spe10').val(data.mastertable[0]['spe10']);
                  $('#spe11').val(data.mastertable[0]['spe11']);
                  $('#spe12').val(data.mastertable[0]['spe12']);
                  $('#spe13').val(data.mastertable[0]['spe13']);
                  $('#spe14').val(data.mastertable[0]['spe14']);
                  $('#spe15').val(data.mastertable[0]['spe15']);
                  $('#spe16').val(data.mastertable[0]['spe16']);

                  $('#con1').val(data.mastertable[0]['con1']);
                  $('#con2').val(data.mastertable[0]['con2']);
                  $('#con3').val(data.mastertable[0]['con3']);
                  $('#con4').val(data.mastertable[0]['con4']);
                  $('#con5').val(data.mastertable[0]['con5']);
                  $('#con6').val(data.mastertable[0]['con6']);
                  $('#con7').val(data.mastertable[0]['con7']);
                  $('#con8').val(data.mastertable[0]['con8']);
                  $('#con9').val(data.mastertable[0]['con9']);
                  $('#con10').val(data.mastertable[0]['con10']);
                  $('#con11').val(data.mastertable[0]['con11']);
                  $('#con12').val(data.mastertable[0]['con12']);
                  $('#con13').val(data.mastertable[0]['con13']);
                  $('#con14').val(data.mastertable[0]['con14']);
                  $('#con15').val(data.mastertable[0]['con15']);
                  $('#con16').val(data.mastertable[0]['con16']);

                  $('#pmt1').val(data.mastertable[0]['pmt1']);
                  $('#pmt2').val(data.mastertable[0]['pmt2']);
                  $('#pmt3').val(data.mastertable[0]['pmt3']);
                  $('#pmt4').val(data.mastertable[0]['pmt4']);
                  $('#pmt5').val(data.mastertable[0]['pmt5']);
                  $('#pmt6').val(data.mastertable[0]['pmt6']);
                  $('#pmt7').val(data.mastertable[0]['pmt7']);
                  $('#pmt8').val(data.mastertable[0]['pmt8']);
                  $('#pmt9').val(data.mastertable[0]['pmt9']);
                  $('#pmt10').val(data.mastertable[0]['pmt10']);
                  $('#pmt11').val(data.mastertable[0]['pmt11']);
                  $('#pmt12').val(data.mastertable[0]['pmt12']);
                  $('#pmt13').val(data.mastertable[0]['pmt13']);
                  $('#pmt14').val(data.mastertable[0]['pmt14']);
                  $('#pmt15').val(data.mastertable[0]['pmt15']);
                  $('#pmt16').val(data.mastertable[0]['pmt16']);

                  $('#material').val(data.mastertable[0]['material']);
                  $('#cr').val(data.mastertable[0]['cr']);
                  $('#usage').val(data.mastertable[0]['usage']);
                  $('#typev').val(data.mastertable[0]['typev']);
                  $('#ipd').val(data.mastertable[0]['ipd']);
                  $('#pdre').val(data.mastertable[0]['pdre']);
                  $('#le').val(data.mastertable[0]['le']);
                  $('#segmentre').val(data.mastertable[0]['segmentre']);
                  $('#lle').val(data.mastertable[0]['lle']);
                  $('#mm').val(data.mastertable[0]['mm']);
                  $('#www').val(data.mastertable[0]['www']);
                  $('#dayss').val(data.mastertable[0]['dayss']);
                  $('#d_date').val(data.mastertable[0]['d_date']);
                  $('#sos').val(data.mastertable[0]['sos']);
                  $('#plan_of_action').val(data.mastertable[0]['plan_of_action']);
                  $('#opth_user_comments').val(data.mastertable[0]['opth_user_comments']);
                  $('#dialysiscon').val(data.mastertable[0]['dialysis_con']);
                  checkdia(data.mastertable[0]['dialysis_con']);
                  $("#dialysis_drops").val(data.mastertable[0]['dialysis_drop']).trigger("change");
                  $("#optho_action").val(data.mastertable[0]['optho_action']).trigger("change");


                  
                 

                  getaddhistorydata(data.mastertable[0]['history_id']);
                  if(doc_examination_id>0)
                  {
                    getaddmedhistorydata(data.mastertable[0]['addmedhistory_id']);
                    $('#addmedhistory_id').val(data.mastertable[0]['addmedhistory_id']);
                    getaddmedhistorysaveddata(data.mastertable[0]['addmedhistory_id']);
                    $('#medicine_doc_remarks').val(data.mastertable[0]['medicine_doc_remarks']);
                     $('#productdetailsinv').children('tbody').html(data.examinationcharges);
                     row_numm=data.countchk;
                     $("#doc_action").val(data.mastertable[0]['doc_action']).trigger("change");
                  }
                  showhisdet();
                  $('#showdataeyecomp').html('');
                  $('#showdataeyecomp').html(data.eyepart);
                  $('#save').hide();
                  $('#update').show();
                  
                  
              } else if(data.error != ''){
                Swal.fire({title:"Warning!",text:""+data.error+"",type:"warning",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },
            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }
        }); 

}

function getaddhistorydata(key)
{        

        $("#overlay").fadeIn(300);
        $('#doctor_medicine').html('');
         $.ajax({
            type: "POST",
            url: 'showhistorydata',
            dataType: "json",
            data: {comprem:$('#hidgen_comp_remarks').val(),opthrem:$('#hidgen_opth_remarks').val(),medrem:$('#hidgen_medi_remarks').val(),key:key,current_meditation:$('#current_meditation').val(),family_history:$('#family_history').val(),drug_history:$('#drug_history').val(),csrf_test_name:csrf},
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != ''){
                $('#comp_medicine').html(data.comp);
                $('#other_history').html(data.otherhistory);
               
              
              } else if(data.error != ''){
                Swal.fire({title:"Warning!",text:""+data.error+"",type:"warning",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },
            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }
        }); 

}

function getaddmedhistorydata(key)
{
        $("#overlay").fadeIn(300);
        $('#doctor_medicine').html('');
         $.ajax({
            type: "POST",
            url: 'showhistorydata',
            dataType: "json",
            data: {key:key,current_meditation:$('#current_meditation').val(),family_history:$('#family_history').val(),drug_history:$('#drug_history').val(),csrf_test_name:csrf},
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != ''){
                $('#doctor_medicine').html(data.docmed);
              
              } else if(data.error != ''){
                Swal.fire({title:"Warning!",text:""+data.error+"",type:"warning",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },
            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }
        }); 

}

function getaddmedhistorysaveddata(key)
{
        $("#overlay").fadeIn(300);

         $.ajax({
            type: "POST",
            url: 'showmedhistorydata',
            dataType: "json",
            data: {key:key,csrf_test_name:csrf},
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != ''){
                
                $('#productdetails').children('tbody').append(data.docmed);
                row_num=data.rowcnt+1;
              
              } else if(data.error != ''){
                Swal.fire({title:"Warning!",text:""+data.error+"",type:"warning",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },
            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }
        }); 

}
<?php
$host_tvm = explode('.',$_SERVER['HTTP_HOST'])[0];

 ?>

function savedata()
{
        $("#overlay").fadeIn(300);
         $.ajax({
            type: "POST",
            url: 'savedata',
            dataType: "json",
            data: $('#examination_saveform').serialize() + "&medicine_doc_remarks="+$('#medicine_doc_remarks').val()+"&gen_comp_remarks="+$('#gen_comp_remarks').val()+"&gen_opth_remarks="+$('#gen_opth_remarks').val()+"&gen_medi_remarks="+$('#gen_medi_remarks').val()+"&family_history="+$('#family_history').val()+"&drug_history="+$('#drug_history').val()+"&current_meditation="+$('#current_meditation').val()+"",
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != ''){
               Swal.fire({title:"",text:""+data.msg+"",type:"success",confirmButtonClass:"btn btn-success",buttonsStyling:!1});
               window.location.href = "https://<?php echo $host_tvm; ?>.argsolution.com/master/Dashboard";
              } else if(data.error != ''){
                Swal.fire({title:"Warning!",text:""+data.error+"",type:"warning",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },
            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }
        }); 

}
function getparticulars(val)
{

    if(val>0)
    {
         $("#overlay").fadeIn(300);
     $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>/master/Common_controller/getparticulars',
            dataType: "json",
            data: {getid: val,csrf_test_name:$('#csrf_test_name').val()},
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != ''){
                $('#particular').html(data.msg);
              } else if(data.error != ''){
                Swal.fire({title:"Warning!",text:""+data.error+"",type:"warning",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },
            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }
        });
    }
}

function updatedataexamination()
{
        $("#overlay").fadeIn(300);
         $.ajax({
            type: "POST",
            url: 'updatedata',
            dataType: "json",
            data: $('#examination_saveform').serialize() + "&medicine_doc_remarks="+$('#medicine_doc_remarks').val()+"&gen_comp_remarks="+$('#hidgen_comp_remarks').val()+"&gen_opth_remarks="+$('#hidgen_opth_remarks').val()+"&gen_medi_remarks="+$('#hidgen_medi_remarks').val()+"&family_history="+$('#family_history').val()+"&drug_history="+$('#drug_history').val()+"&current_meditation="+$('#current_meditation').val()+"",
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != ''){
               Swal.fire({title:"",text:""+data.msg+"",type:"success",confirmButtonClass:"btn btn-success",buttonsStyling:!1});
             window.location.href = "https://<?php echo $host_tvm; ?>.argsolution.com/master/Dashboard";
               
              } else if(data.error != ''){
                Swal.fire({title:"Warning!",text:""+data.error+"",type:"warning",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
              }
                
            },
            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }
        }); 

}


function deletedata(val)
{
    if(val>0)
    {
          Swal.fire({title:"Are you sure?",
            text:"You won't be able to revert this!",
            type:"warning",
            showCancelButton:!0,
            confirmButtonColor:"#3085d6",
            cancelButtonColor:"#d33",
            confirmButtonText:"Yes, Delete it!",
            confirmButtonClass:"btn btn-warning",
            cancelButtonClass:"btn btn-danger ml-1",
            buttonsStyling:!1}).then((function(t){
              if(t.value)
                {
             $("#overlay").fadeIn(300);
                   $.ajax({
            type: "POST",
            url: 'deletedata',
            dataType: "json",
            data: {getid: val,csrf_test_name:csrf},
            success: function(data){
                $("#overlay").fadeOut(300);
               if(data.msg != ''){
               Swal.fire({title:"Deleted",text:""+data.msg+"",type:"success",confirmButtonClass:"btn btn-success",buttonsStyling:!1});
             getexaminationdata();
               
              } else if(data.error != ''){
                Swal.fire({title:"Warning!",text:""+data.error+"",type:"warning",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
               return false;
              } else if(data.error_message) 
              {
                var error = data.error_message;
                var err_str = '';
                for (var key in error) {
                  err_str += error[key] +'\n';
                }
                Swal.fire({title:"Info!",text:""+err_str+"",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                 return false;
              }
                
            },
            error: function (error) {
                Swal.fire({title:"Info!",text:"Network Busy",type:"info",confirmButtonClass:"btn btn-primary",buttonsStyling:!1});
                $("#overlay").fadeOut(300);  
            }
        });
               
                }
                })) 
    }
}

$("input:radio[name=lenstype]").click(function() {
    var value = $(this).val();
     if(value==1)
     {
        $('#Vision').show(500);
        $('#spectacle').hide();
     }
     else
     {
        $('#Vision').hide();
        $('#spectacle').show(500);
        
     }
});




$("input:radio[name=spectacle]").click(function() {
    var value = $(this).val();
     if(value==1)
     {
        $('#spectacle1').show(500);
        $('#spectacle2').hide();
        $('#spectacle3').hide();
     }
     else if(value==2)
     {
        $('#spectacle1').hide();
        $('#spectacle2').show(500);
        $('#spectacle3').hide();
     }
     else
     {
        $('#spectacle1').hide();
        $('#spectacle2').hide();
        $('#spectacle3').show(500);
     }
});

$("input:radio[name=refraction]").click(function() {
    var value = $(this).val();
     if(value==1)
     {
        $('#Objective1').show(500);
        $('#Objective2').hide();
        $('#Objective3').hide();
     }
     else if(value==2)
     {
         $('#Objective1').hide();
        $('#Objective2').show(500);
        $('#Objective3').hide();
     }
     else
     {
         $('#Objective1').hide();
        $('#Objective2').hide();
        $('#Objective3').show(500);
     }
});

function examinationprint(examinationid)
{
   $('<form target="_blank"  method="post" action="<?php echo base_url(); ?>/transaction/Examination/examinationprint"><input name="examinationid" value="'+examinationid+'"/><input name="chkcomplaintsout" value="'+$('#chkcomplaints').is(':checked')+'"><input name="chkopthalmicsout" value="'+$('#chkophthalmic').is(':checked')+'"><input name="chkmedicalout" value="'+$('#chkmedical').is(':checked')+'"><input name="chkeyepartout" value="'+$('#chkeyepart').is(':checked')+'"><input name="addmedicinessout" value="'+$('#addmediciness').is(':checked')+'"><input name="investigationchkout" value="'+$('#investigationchk').is(':checked')+'"><input name="preliminary_exout" value="'+$('#preliminary_ex').is(':checked')+'"><input name="vsisonreadingsout" value="'+$('#vsisonreadings').is(':checked')+'"><input name="curspecout" value="'+$('#curspec').is(':checked')+'"><input name="objectchkout" value="'+$('#objectchk').is(':checked')+'"><input name="arkkchkout" value="'+$('#arkkchk').is(':checked')+'"><input name="manchkout" value="'+$('#manchk').is(':checked')+'"><input name="specchkout" value="'+$('#specchk').is(':checked')+'"><input name="conlchkout" value="'+$('#conlchk').is(':checked')+'"><input name="pmtchkout" value="'+$('#pmtchk').is(':checked')+'"><input name="csrf_test_name" value="'+$('#csrf_test_name').val()+'"></form>').appendTo('body').submit().remove();

}

function printdata()
{
   $('<form target="_blank"  method="post" action="<?php echo base_url(); ?>/transaction/Examination/doctorprintmedicineprescription"><input name="key" value="'+$('#addmedhistory_id').val()+'"/><input name="pid" value="'+$('#patient_registration_id').val()+'"/><input name="paid" value="'+$('#patient_appointment_id').val()+'"/><input name="csrf_test_name" value="'+$('#csrf_test_name').val()+'"></form>').appendTo('body').submit().remove();

}
   
</script>
<style>
.table th, .table td {
    padding: 5px;
}
</style>