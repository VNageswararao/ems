<div class="content-body">

<div class="row">
<div class="col-xl-3 col-lg-6 col-12">
<div class="card bg-gradient-directional-danger">
  <div class="card-content">
    <div class="card-body">
      <div class="media d-flex">
        <div class="media-body text-white text-left">
          <h3 class="text-white">278</h3>
          <span>Today's Patients</span>
        </div>
        <div class="align-self-center">
          <i class="icon-users text-white font-large-2 float-right"></i>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<div class="col-xl-3 col-lg-6 col-12">
<div class="card bg-gradient-directional-success">
  <div class="card-content">
    <div class="card-body">
      <div class="media d-flex">
        <div class="media-body text-white text-left">
          <h3 class="text-white">3490</h3>
          <span>Today's Sales</span>
        </div>
        <div class="align-self-center">
          <i class="la la-credit-card text-white font-large-2 float-right"></i>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<div class="col-xl-3 col-lg-6 col-12">
<div class="card bg-gradient-directional-amber">
  <div class="card-content">
    <div class="card-body">
      <div class="media d-flex">
        <div class="media-body text-white text-left">
          <h3 class="text-white">4500</h3>
          <span>Total  Doctors</span>
        </div>
        <div class="align-self-center">
          <i class="la la-stethoscope text-white font-large-2 float-right"></i>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<div class="col-xl-3 col-lg-6 col-12">
<div class="card bg-gradient-directional-info">
  <div class="card-content">
    <div class="card-body">
      <div class="media d-flex">
        <div class="media-body text-white text-left">
          <h3 class="text-white">1500</h3>
          <span>Total Staff</span>
        </div>
        <div class="align-self-center">
          <i class="icon-users text-white font-large-2 float-right"></i>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>

</div>